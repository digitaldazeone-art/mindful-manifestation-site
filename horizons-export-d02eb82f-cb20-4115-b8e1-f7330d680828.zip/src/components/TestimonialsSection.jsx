import React from 'react';
import { motion } from 'framer-motion';
import { Star, Quote } from 'lucide-react';

const TestimonialsSection = () => {
  const testimonials = [
    {
      name: "Emma Rodriguez",
      role: "Entrepreneur & Mother",
      image: "Professional headshot of a confident Hispanic woman entrepreneur smiling warmly",
      rating: 5,
      text: "This planner completely transformed my approach to goal setting. Within 3 months, I manifested my dream business, improved my relationships, and found a sense of inner peace I never thought possible. The daily practices are simple yet incredibly powerful.",
      highlight: "Manifested dream business in 3 months"
    },
    {
      name: "Michael Thompson",
      role: "Creative Director",
      image: "Professional portrait of a creative man with artistic background and warm smile",
      rating: 5,
      text: "As a skeptic turned believer, I can honestly say this planner works. The combination of practical planning with manifestation principles helped me land my dream job, double my income, and attract amazing opportunities. It's not just a planner—it's a life changer.",
      highlight: "Doubled income and landed dream job"
    },
    {
      name: "Sophia Williams",
      role: "Wellness Coach",
      image: "Portrait of a serene woman wellness coach in natural lighting with plants in background",
      rating: 5,
      text: "The Mindful Manifestation Planner is pure magic! The elegant design makes planning a joy, and the manifestation exercises are incredibly effective. I've manifested my soulmate, my dream home, and a thriving coaching practice. This planner is worth its weight in gold.",
      highlight: "Manifested soulmate and dream home"
    },
    {
      name: "David Kim",
      role: "Tech Executive",
      image: "Professional headshot of an Asian tech executive in modern office setting",
      rating: 5,
      text: "I was amazed by how quickly this planner helped me clarify my vision and take aligned action. The monthly tracking system kept me accountable, and the gratitude practices shifted my entire mindset. I've achieved goals I thought would take years in just months.",
      highlight: "Achieved years worth of goals in months"
    }
  ];

  return (
    <section id="testimonials" className="section-padding bg-gradient-to-br from-amber-50 via-white to-purple-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="font-display text-4xl md:text-5xl font-bold gradient-text mb-6">
            Real Stories, Real Transformations
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Join thousands who have already transformed their lives with The Mindful Manifestation Digital Planner
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              className="group"
            >
              <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-luxury transition-all duration-300 h-full border border-gray-100 relative overflow-hidden">
                {/* Background decoration */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-yellow-100 to-purple-100 rounded-full -translate-y-16 translate-x-16 opacity-50"></div>
                
                {/* Quote icon */}
                <Quote className="w-8 h-8 text-purple-300 mb-4 relative z-10" />
                
                {/* Rating */}
                <div className="flex items-center mb-4 relative z-10">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>

                {/* Testimonial text */}
                <blockquote className="text-gray-700 leading-relaxed mb-6 relative z-10">
                  "{testimonial.text}"
                </blockquote>

                {/* Highlight */}
                <div className="bg-gradient-to-r from-yellow-100 to-purple-100 rounded-lg p-3 mb-6 relative z-10">
                  <p className="text-sm font-semibold text-purple-700">
                    ✨ {testimonial.highlight}
                  </p>
                </div>

                {/* Author info */}
                <div className="flex items-center relative z-10">
                  <div className="w-12 h-12 rounded-full overflow-hidden mr-4 bg-gradient-to-r from-yellow-200 to-purple-200 flex items-center justify-center">
                    <img 
                      alt={testimonial.image}
                      className="w-full h-full object-cover"
                     src="https://images.unsplash.com/photo-1595872018818-97555653a011" />
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-800">{testimonial.name}</h4>
                    <p className="text-sm text-gray-600">{testimonial.role}</p>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Trust indicators */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
          className="text-center mt-16"
        >
          <div className="bg-gradient-to-r from-yellow-100 to-purple-100 rounded-3xl p-8 md:p-12">
            <h3 className="font-display text-2xl md:text-3xl font-bold gradient-text mb-4">
              Join 50,000+ Happy Manifestors
            </h3>
            <div className="flex items-center justify-center space-x-8 text-gray-600">
              <div className="text-center">
                <div className="text-2xl font-bold gradient-text">4.9/5</div>
                <div className="text-sm">Average Rating</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold gradient-text">2,847</div>
                <div className="text-sm">Reviews</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold gradient-text">94%</div>
                <div className="text-sm">Success Rate</div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default TestimonialsSection;