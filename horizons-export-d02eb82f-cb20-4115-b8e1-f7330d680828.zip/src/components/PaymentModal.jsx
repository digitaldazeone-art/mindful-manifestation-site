import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { X, Lock, CreditCard } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from '@/components/ui/use-toast';

const PaymentModal = ({ isOpen, onClose }) => {
  const handlePayment = (e) => {
    e.preventDefault();
    toast({
      title: "🚧 This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
      description: "Real payment processing can be added next!",
      duration: 5000,
    });
    onClose();
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm"
          onClick={onClose}
        >
          <motion.div
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            transition={{ duration: 0.3, ease: "easeInOut" }}
            className="relative bg-creamy-white rounded-2xl shadow-luxury w-full max-w-2xl m-4 overflow-hidden"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="absolute top-4 right-4">
              <Button variant="ghost" size="icon" onClick={onClose} className="rounded-full">
                <X className="h-5 w-5 text-text-light" />
              </Button>
            </div>

            <div className="grid md:grid-cols-2">
              {/* Left Side - Order Summary */}
              <div className="p-8 bg-amber-50 border-r border-amber-100">
                <h2 className="font-display text-2xl font-bold text-text-dark mb-6">Your Order</h2>
                
                <div className="space-y-4">
                  <div className="flex justify-between items-center p-4 bg-white rounded-lg shadow-sm">
                    <div>
                      <p className="font-semibold text-text-dark">Mindful Manifestation Planner</p>
                      <p className="text-sm text-text-light">7-Day Free Trial</p>
                    </div>
                    <p className="font-bold text-text-dark">$0.00</p>
                  </div>

                  <div className="border-t border-dashed border-amber-200 my-4"></div>

                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <p className="text-text-light">Subtotal</p>
                      <p className="text-text-dark">$0.00</p>
                    </div>
                    <div className="flex justify-between">
                      <p className="text-text-light">Tax</p>
                      <p className="text-text-dark">$0.00</p>
                    </div>
                    <div className="flex justify-between font-bold text-lg">
                      <p className="text-text-dark">Total Due Today</p>
                      <p className="text-primary-gold">$0.00</p>
                    </div>
                  </div>
                </div>

                <div className="mt-6 text-xs text-text-light text-center bg-white p-3 rounded-lg">
                  After your 7-day free trial, you will be charged $7.99/month. You can cancel anytime.
                </div>
              </div>

              {/* Right Side - Payment Form */}
              <div className="p-8 bg-white">
                <h2 className="font-display text-2xl font-bold text-text-dark mb-2">Payment Details</h2>
                <p className="text-text-light mb-6 text-sm">Complete your secure payment.</p>
                
                <form onSubmit={handlePayment} className="space-y-4">
                  <div>
                    <Label htmlFor="name">Full Name</Label>
                    <Input id="name" placeholder="Jane Doe" required />
                  </div>
                  <div>
                    <Label htmlFor="email">Email Address</Label>
                    <Input id="email" type="email" placeholder="jane.doe@example.com" required />
                  </div>
                  <div>
                    <Label htmlFor="card">Card Details</Label>
                    <div className="relative">
                      <CreditCard className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
                      <Input id="card" placeholder="Card Number" className="pl-10" required />
                    </div>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="expiry">Expiry</Label>
                      <Input id="expiry" placeholder="MM / YY" required />
                    </div>
                    <div>
                      <Label htmlFor="cvc">CVC</Label>
                      <Input id="cvc" placeholder="CVC" required />
                    </div>
                  </div>

                  <Button type="submit" className="w-full btn-primary text-lg py-6 mt-4 rounded-lg">
                    <Lock className="w-4 h-4 mr-2" />
                    Start Free Trial
                  </Button>
                </form>

                <div className="mt-6">
                  <p className="text-xs text-text-light text-center mb-2">Secure 256-bit SSL encryption</p>
                  <div className="flex items-center justify-center space-x-4 opacity-60">
                    <img alt="Stripe logo" class="h-6" src="https://images.unsplash.com/photo-1678371276694-2dd08ab23f9b" />
                    <img alt="Visa logo" class="h-4" src="https://images.unsplash.com/photo-1654714009937-acf4ffba1202" />
                    <img alt="Mastercard logo" class="h-5" src="https://images.unsplash.com/photo-1611416811039-e326d73a68d3" />
                    <img alt="American Express logo" class="h-5" src="https://images.unsplash.com/photo-1649251855096-f8beda8f6b24" />
                  </div>
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
};

export default PaymentModal;