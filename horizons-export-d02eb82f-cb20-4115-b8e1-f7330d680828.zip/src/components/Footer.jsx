import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Facebook, Instagram, Twitter, Linkedin } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const Footer = () => {
  const currentYear = new Date().getFullYear();
  const navigate = useNavigate();
  const { toast } = useToast();

  const footerLinks = {
    company: [
      { name: 'About Us', href: '/#author' },
      { name: 'Contact', href: 'mailto:info@example.com' },
    ],
    legal: [
      { name: 'Privacy Policy', href: '/privacy-policy' },
      { name: 'Terms of Service', href: '/terms-of-service' },
      { name: 'Refund Policy', href: '/refund-policy' },
      { name: 'Disclaimer', href: '/disclaimer' },
    ],
    resources: [
      { name: 'FAQ', href: '/#faq' },
      { name: 'Blog', href: 'javascript:void(0)' },
      { name: 'Support', href: '/support' },
    ],
  };

  const socialLinks = [
    { icon: Facebook, href: 'javascript:void(0)', label: 'Facebook' },
    { icon: Instagram, href: 'javascript:void(0)', label: 'Instagram' },
    { icon: Twitter, href: 'javascript:void(0)', label: 'Twitter' },
    { icon: Linkedin, href: 'javascript:void(0)', label: 'LinkedIn' },
  ];

  const handleLinkClick = (e, href) => {
    if (href.startsWith('javascript:void(0)')) {
      e.preventDefault();
      toast({
        title: "🚧 Feature In Progress",
        description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
      });
    } else if (href.startsWith('/#')) {
      e.preventDefault();
      navigate(href);
    }
  };

  const renderLink = (link, className) => {
    if (link.href.startsWith('/') && !link.href.includes('#')) {
      return (
        <Link to={link.href} className={className}>
          {link.name}
        </Link>
      );
    }
    return (
      <a href={link.href} onClick={(e) => handleLinkClick(e, link.href)} className={className}>
        {link.name}
      </a>
    );
  };

  return (
    <footer className="bg-gradient-to-r from-purple-800 to-indigo-900 text-white py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand Info */}
          <div className="space-y-4">
            <Link to="/" className="font-display font-bold text-3xl gradient-text-white">
              Mindful Manifestation
            </Link>
            <p className="text-gray-300 text-sm leading-relaxed">
              Unlock your potential and design your dream life with our transformative digital planner.
            </p>
            <div className="flex space-x-4 mt-4">
              {socialLinks.map((social, index) => (
                <motion.a
                  key={index}
                  href={social.href}
                  aria-label={social.label}
                  whileHover={{ scale: 1.2, color: '#a78bfa' }}
                  whileTap={{ scale: 0.9 }}
                  onClick={(e) => handleLinkClick(e, social.href)}
                  className="text-gray-300 hover:text-purple-400 transition-colors duration-200"
                >
                  <social.icon size={24} />
                </motion.a>
              ))}
            </div>
          </div>

          {/* Company Links */}
          <div>
            <span className="font-semibold text-lg mb-4 block">Company</span>
            <ul className="space-y-2">
              {footerLinks.company.map((link, index) => (
                <li key={index}>
                  {renderLink(link, "text-gray-300 hover:text-purple-400 transition-colors duration-200 text-sm")}
                </li>
              ))}
            </ul>
          </div>

          {/* Legal Links */}
          <div>
            <span className="font-semibold text-lg mb-4 block">Legal</span>
            <ul className="space-y-2">
              {footerLinks.legal.map((link, index) => (
                <li key={index}>
                  {renderLink(link, "text-gray-300 hover:text-purple-400 transition-colors duration-200 text-sm")}
                </li>
              ))}
            </ul>
          </div>

          {/* Resources Links */}
          <div>
            <span className="font-semibold text-lg mb-4 block">Resources</span>
            <ul className="space-y-2">
              {footerLinks.resources.map((link, index) => (
                <li key={index}>
                  {renderLink(link, "text-gray-300 hover:text-purple-400 transition-colors duration-200 text-sm")}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-700 mt-10 pt-8 text-center text-gray-400 text-sm">
          <p>&copy; {currentYear} Mindful Manifestation. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;