import React from 'react';
import { motion } from 'framer-motion';
import { Target, Zap, Heart, TrendingUp, Sparkles, Crown } from 'lucide-react';

const BenefitsSection = () => {
  const benefits = [
    {
      icon: Crown,
      title: "Design Your Dream Life",
      description: "Create a clear vision of your ideal future with guided exercises and elegant planning templates that turn dreams into actionable goals.",
      color: "from-yellow-400 to-amber-500"
    },
    {
      icon: Zap,
      title: "Master Your Energy",
      description: "Learn powerful techniques to align your energy with your desires, featuring daily practices that elevate your vibration and attract abundance.",
      color: "from-purple-500 to-purple-600"
    },
    {
      icon: Heart,
      title: "Cultivate Daily Gratitude",
      description: "Transform your mindset with beautiful gratitude practices that shift your focus to abundance and create a magnetic field for more blessings.",
      color: "from-pink-400 to-rose-500"
    },
    {
      icon: TrendingUp,
      title: "Achieve Your Goals Faster",
      description: "Break down your biggest dreams into manageable steps with our proven manifestation framework that accelerates your success timeline.",
      color: "from-emerald-400 to-teal-500"
    }
  ];

  return (
    <section id="benefits" className="section-padding bg-gradient-to-br from-white via-amber-50 to-purple-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="flex items-center justify-center mb-4">
            <Sparkles className="w-8 h-8 text-yellow-500 mr-2" />
            <span className="text-lg font-semibold text-purple-600">Transform Your Reality</span>
            <Sparkles className="w-8 h-8 text-yellow-500 ml-2" />
          </div>
          <h2 className="font-display text-4xl md:text-5xl font-bold gradient-text mb-6">
            Unlock Your Full Potential
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Experience the profound transformation that comes from aligning your thoughts, emotions, and actions with your deepest desires.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {benefits.map((benefit, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ y: -10 }}
              className="group"
            >
              <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-luxury transition-all duration-300 h-full border border-gray-100">
                <div className={`w-16 h-16 rounded-2xl bg-gradient-to-r ${benefit.color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform duration-300`}>
                  <benefit.icon className="w-8 h-8 text-white" />
                </div>
                
                <h3 className="font-display text-xl font-bold text-gray-800 mb-4">
                  {benefit.title}
                </h3>
                
                <p className="text-gray-600 leading-relaxed">
                  {benefit.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
          className="text-center mt-16"
        >
          <div className="bg-gradient-to-r from-yellow-100 to-purple-100 rounded-3xl p-8 md:p-12">
            <h3 className="font-display text-2xl md:text-3xl font-bold gradient-text mb-4">
              Join Thousands Who've Transformed Their Lives
            </h3>
            <p className="text-lg text-gray-700 mb-6">
              "This planner didn't just organize my goals—it completely shifted my reality. I manifested my dream job, improved relationships, and found inner peace I never thought possible."
            </p>
            <div className="flex items-center justify-center space-x-2">
              <div className="flex">
                {[...Array(5)].map((_, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, scale: 0 }}
                    whileInView={{ opacity: 1, scale: 1 }}
                    transition={{ delay: i * 0.1 }}
                    viewport={{ once: true }}
                  >
                    <Target className="w-5 h-5 text-yellow-400 fill-current" />
                  </motion.div>
                ))}
              </div>
              <span className="text-gray-600 font-medium">Average transformation time: 30 days</span>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default BenefitsSection;