import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ChevronDown, HelpCircle } from 'lucide-react';

const FAQSection = () => {
  const [openIndex, setOpenIndex] = useState(0);

  const faqs = [
    {
      question: "What is a digital planner?",
      answer: "A digital planner is an interactive PDF that you can use on your tablet, phone, or computer. Unlike traditional planners, it offers unlimited pages, easy editing, and the ability to add multimedia elements. Our Mindful Manifestation Digital Planner includes clickable links, fillable forms, and beautiful interactive elements that make planning a joy."
    },
    {
      question: "How does it help with manifestation?",
      answer: "Our planner combines proven manifestation techniques with practical planning tools. It includes guided visualization exercises, goal-setting frameworks, gratitude practices, and energy alignment activities. The structured approach helps you clarify your desires, maintain focus, and take consistent aligned action—the key ingredients for successful manifestation."
    },
    {
      question: "What devices is it compatible with?",
      answer: "The planner works on all devices that support PDF files, including iPads, Android tablets, smartphones, Mac, PC, and Chromebooks. For the best experience, we recommend using apps like GoodNotes, Notability, or Adobe Acrobat Reader. You can sync across all your devices and access your planner anywhere."
    },
    {
      question: "Is there customer support?",
      answer: "Absolutely! We provide comprehensive customer support including setup guides, video tutorials, and direct email support. Our team responds within 24 hours and we're committed to ensuring you get the most out of your manifestation journey. Plus, you'll get access to our private community of manifestors."
    },
    {
      question: "Can I print the planner?",
      answer: "Yes! While designed for digital use, you can print any pages you'd like. The planner is optimized for both digital and print formats, so you'll get beautiful results either way. Many users enjoy printing their vision boards and goal pages to display as daily reminders."
    },
    {
      question: "How is this different from other planners?",
      answer: "Our planner uniquely combines elegant design with powerful manifestation science. Unlike generic planners, every page is intentionally designed to elevate your vibration and align your energy. We include exclusive techniques from Dr. Sarah Chen's 15+ years of research, plus bonus resources you won't find anywhere else."
    },
    {
      question: "What if I'm new to manifestation?",
      answer: "Perfect! The planner is designed for all levels, from complete beginners to advanced practitioners. We include step-by-step guides, explanations of key concepts, and gentle introduction exercises. You'll learn as you go, with each section building upon the previous one to create a solid foundation."
    },
    {
      question: "How long does it take to see results?",
      answer: "While everyone's journey is unique, most users report positive shifts within the first week of consistent use. Significant manifestations typically occur within 30-90 days of regular practice. The key is consistency—even 10 minutes daily with your planner can create profound changes in your life."
    }
  ];

  return (
    <section id="faq" className="section-padding bg-gradient-to-br from-purple-50 via-white to-amber-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <div className="flex items-center justify-center mb-4">
            <HelpCircle className="w-8 h-8 text-purple-600 mr-2" />
            <span className="text-lg font-semibold text-purple-600">Got Questions?</span>
          </div>
          <h2 className="font-display text-4xl md:text-5xl font-bold gradient-text mb-6">
            Frequently Asked Questions
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Everything you need to know about The Mindful Manifestation Digital Planner
          </p>
        </motion.div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: index * 0.05 }}
              viewport={{ once: true }}
              className="bg-white rounded-2xl shadow-lg border border-gray-100 overflow-hidden"
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? -1 : index)}
                className="w-full px-8 py-6 text-left flex items-center justify-between hover:bg-gray-50 transition-colors duration-200"
              >
                <h3 className="font-semibold text-lg text-gray-800 pr-4">
                  {faq.question}
                </h3>
                <motion.div
                  animate={{ rotate: openIndex === index ? 180 : 0 }}
                  transition={{ duration: 0.3 }}
                  className="flex-shrink-0"
                >
                  <ChevronDown className="w-6 h-6 text-purple-600" />
                </motion.div>
              </button>
              
              <AnimatePresence>
                {openIndex === index && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3 }}
                    className="overflow-hidden"
                  >
                    <div className="px-8 pb-6">
                      <p className="text-gray-600 leading-relaxed">
                        {faq.answer}
                      </p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.4 }}
          viewport={{ once: true }}
          className="text-center mt-12"
        >
          <div className="bg-gradient-to-r from-yellow-100 to-purple-100 rounded-2xl p-8">
            <h3 className="font-display text-xl font-bold gradient-text mb-4">
              Still have questions?
            </h3>
            <p className="text-gray-700 mb-4">
              Our support team is here to help you succeed on your manifestation journey.
            </p>
            <a 
              href="mailto:support@mindfulmanifestationplanner.com"
              className="text-purple-600 font-semibold hover:text-purple-700 transition-colors"
            >
              Contact us at support@mindfulmanifestationplanner.com
            </a>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default FAQSection;