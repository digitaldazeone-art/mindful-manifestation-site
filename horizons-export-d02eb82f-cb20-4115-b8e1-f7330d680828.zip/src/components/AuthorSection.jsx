import React from 'react';
import { motion } from 'framer-motion';
import { Award, BookOpen, Users, Star } from 'lucide-react';

const AuthorSection = () => {
  const achievements = [
    { icon: BookOpen, number: "5+", label: "Published Works" },
    { icon: Users, number: "50K+", label: "Lives Transformed" },
    { icon: Award, number: "15+", label: "Years Experience" },
    { icon: Star, number: "4.9", label: "Average Rating" }
  ];

  return (
    <section id="author" className="section-padding bg-gradient-to-br from-white via-purple-50 to-amber-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="font-display text-4xl md:text-5xl font-bold gradient-text mb-6">
            Meet Your Guide
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Discover the wisdom and experience behind The Mindful Manifestation Digital Planner
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Author Image */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-yellow-400 to-purple-500 rounded-3xl blur-2xl opacity-20"></div>
              <div className="relative bg-white rounded-3xl shadow-luxury p-6">
                <img 
                  alt="Dr. Sarah Chen, manifestation expert and author, smiling warmly in professional attire with books and crystals in background"
                  className="w-full h-auto rounded-2xl"
                 src="https://images.unsplash.com/photo-1503835934622-991d728950c7" />
              </div>
            </div>
          </motion.div>

          {/* Author Bio */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="space-y-6"
          >
            <div>
              <h3 className="font-display text-3xl font-bold text-gray-800 mb-2">Dr. Sarah Chen</h3>
              <p className="text-xl text-purple-600 font-medium mb-4">Manifestation Expert & Life Transformation Coach</p>
            </div>

            <div className="space-y-4 text-gray-600 leading-relaxed">
              <p>
                Dr. Sarah Chen is a renowned manifestation expert with over 15 years of experience helping individuals transform their lives through the power of conscious creation. With a PhD in Psychology and certifications in mindfulness and energy healing, she combines scientific rigor with spiritual wisdom.
              </p>
              <p>
                Her unique approach to manifestation has been featured in major publications and has helped over 50,000 people worldwide create their dream lives. Sarah's work focuses on the intersection of neuroscience, quantum physics, and ancient wisdom traditions.
              </p>
              <p>
                When she's not writing or coaching, Sarah enjoys meditation retreats, traveling to sacred sites around the world, and spending time in nature with her family.
              </p>
            </div>

            {/* Achievements */}
            <div className="grid grid-cols-2 gap-4 mt-8">
              {achievements.map((achievement, index) => (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  viewport={{ once: true }}
                  className="bg-white rounded-xl p-4 shadow-md text-center"
                >
                  <achievement.icon className="w-8 h-8 text-purple-600 mx-auto mb-2" />
                  <div className="font-bold text-2xl gradient-text">{achievement.number}</div>
                  <div className="text-sm text-gray-600">{achievement.label}</div>
                </motion.div>
              ))}
            </div>

            {/* Quote */}
            <motion.div
              initial={{ opacity: 0 }}
              whileInView={{ opacity: 1 }}
              transition={{ duration: 0.8, delay: 0.4 }}
              viewport={{ once: true }}
              className="bg-gradient-to-r from-yellow-100 to-purple-100 rounded-xl p-6 mt-8"
            >
              <blockquote className="text-lg italic text-gray-700 mb-4">
                "Manifestation isn't magic—it's a science. When you align your thoughts, emotions, and actions with your deepest desires, you become an unstoppable force of creation."
              </blockquote>
              <cite className="text-purple-600 font-semibold">— Dr. Sarah Chen</cite>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
};

export default AuthorSection;