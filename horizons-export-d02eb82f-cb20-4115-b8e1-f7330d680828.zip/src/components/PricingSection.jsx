import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import PaymentModal from '@/components/PaymentModal';

const PricingSection = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const features = [
    "The Complete Mindful Manifestation Digital Planner (PDF)",
    "Lifetime Access & Future Updates",
    "Printable & Digital Versions",
    "Guided Goal Setting Worksheets",
    "Daily, Weekly & Monthly Layouts",
    "Habit & Mood Trackers",
    "Bonus: Abundance Affirmation Cards",
    "Bonus: Guided Meditation Video Library"
  ];

  return (
    <>
      <section id="pricing" className="section-padding bg-creamy-white">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            viewport={{ once: true }}
            className="bg-white rounded-3xl shadow-luxury overflow-hidden"
          >
            <div className="grid lg:grid-cols-2">
              {/* Left Side - Features */}
              <div className="p-8 md:p-12 bg-gradient-to-br from-purple-50 via-white to-amber-50">
                <h2 className="font-display text-3xl md:text-4xl font-bold gradient-text mb-6">
                  Get Instant Access Today
                </h2>
                <p className="text-gray-600 mb-8 leading-relaxed">
                  Join thousands of successful manifestors and start designing your dream life with intention and elegance.
                </p>
                <div className="space-y-4">
                  {features.map((feature, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      transition={{ duration: 0.5, delay: index * 0.1 }}
                      viewport={{ once: true }}
                      className="flex items-start"
                    >
                      <CheckCircle className="w-6 h-6 text-purple-500 mr-3 mt-1 flex-shrink-0" />
                      <span className="text-gray-700">{feature}</span>
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Right Side - Pricing & CTA */}
              <div className="p-8 md:p-12 flex flex-col justify-center items-center text-center bg-white">
                <div className="w-full">
                  <div className="flex justify-center items-baseline mb-4">
                    <Star className="w-5 h-5 text-yellow-400 fill-current" />
                    <Star className="w-5 h-5 text-yellow-400 fill-current" />
                    <Star className="w-5 h-5 text-yellow-400 fill-current" />
                    <Star className="w-5 h-5 text-yellow-400 fill-current" />
                    <Star className="w-5 h-5 text-yellow-400 fill-current" />
                  </div>
                  <p className="text-gray-600 mb-6 font-medium">"This planner changed my life! I'm manifesting goals I never thought possible."</p>
                  
                  <div className="mb-6">
                    <div className="flex justify-center items-baseline mb-2">
                      <span className="text-lg text-gray-500 line-through mr-2"></span>
                      <span className="font-display text-6xl font-bold text-purple-600">Free</span>
                    </div>
                    <p className="text-gray-500">7-Day trial and only $7.99 a month after.</p>
                  </div>

                  <motion.div whileHover={{ scale: 1.05 }} className="w-full">
                    <Button 
                      size="lg" 
                      className="btn-primary w-full text-white text-xl font-bold py-8 rounded-xl shadow-lg"
                      onClick={() => setIsModalOpen(true)}
                    >
                      Start Your Free Trial Now
                    </Button>
                  </motion.div>
                  
                  <p className="text-xs text-gray-400 mt-4">30-Day Money-Back Guarantee</p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </section>
      <PaymentModal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} />
    </>
  );
};

export default PricingSection;