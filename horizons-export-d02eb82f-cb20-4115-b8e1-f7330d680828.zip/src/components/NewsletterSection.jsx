import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, BookOpen, Sparkles, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/components/ui/use-toast';

const NewsletterSection = () => {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!email) {
      toast({
        variant: "destructive",
        title: "Whoops!",
        description: "Please enter your email address.",
      });
      return;
    }
    setLoading(true);

    try {
      const response = await fetch('/.netlify/functions/send-ebook', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email }),
      });

      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || 'Something went wrong.');
      }

      toast({
        title: "Success! ✨",
        description: "Your free ebook is on its way to your inbox!",
      });
      setEmail('');

    } catch (error) {
      console.error("Fetch error:", error);
      toast({
        variant: "destructive",
        title: "Oh no! Something went wrong.",
        description: error.message,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <section className="section-padding bg-gradient-to-br from-purple-50 via-white to-amber-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          viewport={{ once: true }}
          className="text-center"
        >
          <div className="bg-gradient-to-r from-yellow-100 to-purple-100 rounded-3xl p-8 md:p-12 relative overflow-hidden">
            <div className="absolute top-0 left-0 w-32 h-32 bg-gradient-to-br from-yellow-200 to-amber-300 rounded-full -translate-x-16 -translate-y-16 opacity-30"></div>
            <div className="absolute bottom-0 right-0 w-32 h-32 bg-gradient-to-br from-purple-200 to-purple-400 rounded-full translate-x-16 translate-y-16 opacity-30"></div>
            
            <div className="relative z-10">
              <div className="flex items-center justify-center mb-6">
                <BookOpen className="w-8 h-8 text-purple-600 mr-2" />
                <span className="text-lg font-semibold text-purple-600">Free Mindful Manifestation Ebook</span>
                <Sparkles className="w-8 h-8 text-yellow-500 ml-2" />
              </div>

              <h2 className="font-display text-3xl md:text-4xl font-bold gradient-text mb-6">
                Get Your Free Mindful Manifestation Ebook
              </h2>
              
              <p className="text-lg text-gray-700 mb-8 max-w-2xl mx-auto">
                Join our community and receive exclusive manifestation tips, free resources, and early access to new content. Plus, get your free 'Mindful Manifestation Ebook' instantly!
              </p>

              <form onSubmit={handleSubmit} className="max-w-md mx-auto mb-6">
                <div className="flex flex-col sm:flex-row gap-4">
                  <div className="flex-1 relative">
                    <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="Enter your email address"
                      className="w-full pl-10 pr-4 py-3 rounded-full border border-gray-300 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                      required
                      disabled={loading}
                    />
                  </div>
                  <Button
                    type="submit"
                    className="btn-secondary text-white px-8 py-3 rounded-full font-semibold whitespace-nowrap"
                    disabled={loading}
                  >
                    {loading ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Sending...</> : 'Get Free Ebook'}
                  </Button>
                </div>
              </form>

              <div className="grid md:grid-cols-3 gap-4 text-sm text-gray-600">
                <div className="flex items-center justify-center">
                  <BookOpen className="w-4 h-4 text-yellow-500 mr-2" />
                  <span>Instant Ebook Access</span>
                </div>
                <div className="flex items-center justify-center">
                  <Sparkles className="w-4 h-4 text-purple-500 mr-2" />
                  <span>Exclusive Content</span>
                </div>
                <div className="flex items-center justify-center">
                  <Mail className="w-4 h-4 text-blue-500 mr-2" />
                  <span>Weekly Insights</span>
                </div>
              </div>

              <p className="text-xs text-gray-500 mt-4">
                No spam, ever. Unsubscribe anytime with one click.
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default NewsletterSection;