import React from 'react';
import { motion } from 'framer-motion';
import { BookOpen, Calendar, Target, Heart, Sparkles } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';

const PreviewSection = () => {
  const { toast } = useToast();
  const chapters = [{
    icon: Sparkles,
    title: "Manifestation Foundations",
    description: "Master the core principles of conscious creation and learn how to align your thoughts with your desires.",
    pages: "12 pages"
  }, {
    icon: Target,
    title: "Goal Setting & Vision Boards",
    description: "Create crystal-clear visions of your future with our proven goal-setting framework and digital vision board templates.",
    pages: "18 pages"
  }, {
    icon: Heart,
    title: "Daily Gratitude & Affirmations",
    description: "Transform your mindset with powerful daily practices that elevate your vibration and attract abundance.",
    pages: "15 pages"
  }, {
    icon: Calendar,
    title: "Monthly Planning & Tracking",
    description: "Organize your manifestation journey with beautiful monthly layouts and progress tracking systems.",
    pages: "24 pages"
  }, {
    icon: BookOpen,
    title: "Reflection & Growth",
    description: "Deepen your self-awareness with guided reflection prompts and personal growth exercises.",
    pages: "16 pages"
  }];

  return <section id="preview" className="section-padding bg-gradient-to-br from-purple-50 via-white to-amber-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div initial={{
        opacity: 0,
        y: 30
      }} whileInView={{
        opacity: 1,
        y: 0
      }} transition={{
        duration: 0.8
      }} viewport={{
        once: true
      }} className="text-center mb-16">
          <h2 className="font-display text-4xl md:text-5xl font-bold gradient-text mb-6">
            Inside Your Digital Planner
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Discover the comprehensive system that will guide you through every step of your manifestation journey with elegance and intention.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          {/* Preview Image */}
          <motion.div initial={{
          opacity: 0,
          x: -50
        }} whileInView={{
          opacity: 1,
          x: 0
        }} transition={{
          duration: 0.8
        }} viewport={{
          once: true
        }} className="relative">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-r from-purple-400 to-yellow-400 rounded-3xl blur-2xl opacity-20"></div>
              <div className="relative bg-white rounded-3xl shadow-luxury p-6">
                <img alt="Digital planner preview showing manifestation pages with elegant layouts, goal tracking, and gratitude sections" className="w-full h-auto rounded-2xl" src="https://horizons-cdn.hostinger.com/d02eb82f-cb20-4115-b8e1-f7330d680828/09a1f501058d8a7117f4f7a7d06c6b10.png" />
              </div>
            </div>
          </motion.div>

          {/* Chapters List */}
          <motion.div initial={{
          opacity: 0,
          x: 50
        }} whileInView={{
          opacity: 1,
          x: 0
        }} transition={{
          duration: 0.8
        }} viewport={{
          once: true
        }} className="space-y-6">
            {chapters.map((chapter, index) => <motion.div key={index} initial={{
            opacity: 0,
            y: 20
          }} whileInView={{
            opacity: 1,
            y: 0
          }} transition={{
            duration: 0.6,
            delay: index * 0.1
          }} viewport={{
            once: true
          }} className="flex items-start space-x-4 p-4 bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow duration-300">
                <div className="flex-shrink-0 w-12 h-12 bg-gradient-to-r from-purple-500 to-yellow-500 rounded-xl flex items-center justify-center">
                  <chapter.icon className="w-6 h-6 text-white" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-semibold text-gray-800">{chapter.title}</h3>
                    <span className="text-sm text-purple-600 font-medium">{chapter.pages}</span>
                  </div>
                  <p className="text-gray-600 text-sm leading-relaxed">{chapter.description}</p>
                </div>
              </motion.div>)}
          </motion.div>
        </div>
      </div>
    </section>;
};
export default PreviewSection;