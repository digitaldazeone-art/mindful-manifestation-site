import React from 'react';

export const EbookEmail = ({ email }) => (
  <div>
    <h1>Thank you for subscribing!</h1>
    <p>Here is your free Mindful Manifestation Ebook. We're so excited to have you on this journey with us.</p>
    <p><a href="https://mindfulmanifestation.life/ebook.pdf" target="_blank" rel="noopener noreferrer">Click here to download your ebook</a></p>
    <p>With gratitude,</p>
    <p>The Mindful Manifestation Team</p>
  </div>
);