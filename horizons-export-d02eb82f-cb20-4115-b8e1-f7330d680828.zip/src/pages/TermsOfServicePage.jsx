import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

const LegalPageLayout = ({ title, children }) => (
  <div className="bg-gradient-to-b from-purple-50 via-white to-amber-50 py-12 md:py-20">
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
      >
        <div className="mb-8">
          <Link to="/" className="inline-flex items-center gap-2 text-text-dark hover:text-primary-gold transition-colors">
            <ArrowLeft size={16} />
            Back to Home
          </Link>
        </div>
        <div className="bg-white p-8 md:p-12 rounded-2xl shadow-luxury">
          <h1 className="font-display text-3xl md:text-5xl font-bold gradient-text mb-8 text-center">
            {title}
          </h1>
          <div className="prose prose-lg max-w-none text-text-light">
            {children}
          </div>
        </div>
      </motion.div>
    </div>
  </div>
);

const TermsOfServicePage = () => {
  return (
    <>
      <Helmet>
        <title>Terms of Service - Mindful Manifestation</title>
        <meta name="description" content="Terms of Service for the Mindful Manifestation Digital Planner website and products." />
      </Helmet>
      <LegalPageLayout title="Terms of Service">
        <p>Last updated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
        <p>Please read these Terms of Service ("Terms", "Terms of Service") carefully before using the Mindful Manifestation website (the "Service") operated by Mindful Manifestation ("us", "we", or "our").</p>
        
        <h2>1. Agreement to Terms</h2>
        <p>By accessing or using the Service you agree to be bound by these Terms. If you disagree with any part of the terms then you may not access the Service.</p>

        <h2>2. Purchases</h2>
        <p>If you wish to purchase any product or service made available through the Service ("Purchase"), you may be asked to supply certain information relevant to your Purchase including, without limitation, your credit card number, the expiration date of your credit card, your billing address, and your shipping information.</p>

        <h2>3. Intellectual Property</h2>
        <p>The Service and its original content (excluding Content provided by users), features and functionality are and will remain the exclusive property of Mindful Manifestation and its licensors. The Mindful Manifestation Digital Planner is for personal use only. You may not share, sell, alter, or replicate these files. By purchasing this product, you agree to my shop policies.</p>

        <h2>4. Links To Other Web Sites</h2>
        <p>Our Service may contain links to third-party web sites or services that are not owned or controlled by Mindful Manifestation. We have no control over, and assume no responsibility for, the content, privacy policies, or practices of any third party web sites or services.</p>

        <h2>5. Termination</h2>
        <p>We may terminate or suspend your access immediately, without prior notice or liability, for any reason whatsoever, including without limitation if you breach the Terms.</p>

        <h2>6. Governing Law</h2>
        <p>These Terms shall be governed and construed in accordance with the laws of the jurisdiction in which our company is established, without regard to its conflict of law provisions.</p>

        <h2>7. Changes</h2>
        <p>We reserve the right, at our sole discretion, to modify or replace these Terms at any time. What constitutes a material change will be determined at our sole discretion.</p>

        <h2>8. Contact Us</h2>
        <p>If you have any questions about these Terms, please contact us: support@mindfulmanifestation.com</p>
      </LegalPageLayout>
    </>
  );
};

export default TermsOfServicePage;