import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

const LegalPageLayout = ({ title, children }) => (
  <div className="bg-gradient-to-b from-purple-50 via-white to-amber-50 py-12 md:py-20">
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
      >
        <div className="mb-8">
          <Link to="/" className="inline-flex items-center gap-2 text-text-dark hover:text-primary-gold transition-colors">
            <ArrowLeft size={16} />
            Back to Home
          </Link>
        </div>
        <div className="bg-white p-8 md:p-12 rounded-2xl shadow-luxury">
          <h1 className="font-display text-3xl md:text-5xl font-bold gradient-text mb-8 text-center">
            {title}
          </h1>
          <div className="prose prose-lg max-w-none text-text-light">
            {children}
          </div>
        </div>
      </motion.div>
    </div>
  </div>
);

const RefundPolicyPage = () => {
  return (
    <>
      <Helmet>
        <title>Refund Policy - Mindful Manifestation</title>
        <meta name="description" content="Refund Policy for the Mindful Manifestation Digital Planner website and products." />
      </Helmet>
      <LegalPageLayout title="Refund Policy">
        <p>Last updated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
        
        <h2>Digital Products</h2>
        <p>Due to the digital nature of our products, we generally do not offer refunds or exchanges once a file has been purchased. As you receive the product immediately after purchase, we are unable to process returns.</p>
        <p>We want you to be 100% satisfied with your purchase. If you encounter any issues with your digital files, such as a corrupt file or trouble downloading, please contact us immediately at support@mindfulmanifestation.com. We will work with you to resolve the issue promptly.</p>

        <h2>30-Day Money-Back Guarantee</h2>
        <p>Despite the digital nature of our products, we stand by their quality and offer a 30-day money-back guarantee. If you are not satisfied with your purchase for any reason, you may request a full refund within 30 days of your purchase date.</p>
        <p>To request a refund, please email us at support@mindfulmanifestation.com with your order number and a brief explanation of why you are requesting a refund. We appreciate your feedback as it helps us improve our products.</p>
        <p>Refunds will be processed to the original payment method within 5-10 business days.</p>

        <h2>Exceptions</h2>
        <p>No refunds will be granted after 30 days from the date of purchase. We do not provide refunds for accidental purchases or if you have changed your mind after the 30-day period.</p>

        <h2>Contact Us</h2>
        <p>If you have any questions about our Refund Policy, please contact us: support@mindfulmanifestation.com</p>
      </LegalPageLayout>
    </>
  );
};

export default RefundPolicyPage;