import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

const LegalPageLayout = ({ title, children }) => (
  <div className="bg-gradient-to-b from-purple-50 via-white to-amber-50 py-12 md:py-20">
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
      >
        <div className="mb-8">
          <Link to="/" className="inline-flex items-center gap-2 text-text-dark hover:text-primary-gold transition-colors">
            <ArrowLeft size={16} />
            Back to Home
          </Link>
        </div>
        <div className="bg-white p-8 md:p-12 rounded-2xl shadow-luxury">
          <h1 className="font-display text-3xl md:text-5xl font-bold gradient-text mb-8 text-center">
            {title}
          </h1>
          <div className="prose prose-lg max-w-none text-text-light">
            {children}
          </div>
        </div>
      </motion.div>
    </div>
  </div>
);

const DisclaimerPage = () => {
  return (
    <>
      <Helmet>
        <title>Disclaimer - Mindful Manifestation</title>
        <meta name="description" content="Disclaimer for the Mindful Manifestation Digital Planner website and products." />
      </Helmet>
      <LegalPageLayout title="Disclaimer">
        <p>Last updated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
        <p>The information provided by Mindful Manifestation ("we," "us," or "our") on our website and through our digital products is for general informational and educational purposes only. All information is provided in good faith, however, we make no representation or warranty of any kind, express or implied, regarding the accuracy, adequacy, validity, reliability, availability, or completeness of any information.</p>
        
        <h2>For Educational and Informational Purposes Only</h2>
        <p>The content of the Mindful Manifestation Digital Planner and any related materials is for educational and informational purposes only. It is not intended as a substitute for professional advice. You should not rely on this information as a substitute for, nor does it replace, professional medical, legal, financial, or psychological advice.</p>

        <h2>Personal Responsibility</h2>
        <p>You acknowledge that you are participating voluntarily in using our website and products and that you are solely and personally responsible for your choices, actions, and results, now and in the future. You accept full responsibility for the consequences of your use, or non-use, of any information provided on or through this website, and you agree to use your own judgment and due diligence before implementing any idea, suggestion, or recommendation from our website to your life, family, or business.</p>

        <h2>No Guarantees</h2>
        <p>Our role is to support and assist you in reaching your own goals, but your success depends primarily on your own effort, motivation, commitment, and follow-through. We cannot predict and we do not guarantee that you will attain a particular result, and you accept and understand that results differ for each individual. Each individual’s results depend on their unique background, dedication, desire, motivation, actions, and numerous other factors.</p>

        <h2>Testimonials</h2>
        <p>We present real-world experiences, testimonials, and insights about other people’s experiences with our website for purposes of illustration only. The testimonials, examples, and photos used are of actual clients and results they personally achieved, or they are comments from individuals who can speak to our character and/or the quality of our work. They are not intended to represent or guarantee that current or future clients will achieve the same or similar results.</p>
      </LegalPageLayout>
    </>
  );
};

export default DisclaimerPage;