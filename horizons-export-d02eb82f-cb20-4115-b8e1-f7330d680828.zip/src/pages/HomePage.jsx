
import React from 'react';
import { Helmet } from 'react-helmet';
import HeroSection from '@/components/HeroSection';
import BenefitsSection from '@/components/BenefitsSection';
import PreviewSection from '@/components/PreviewSection';
import AuthorSection from '@/components/AuthorSection';
import TestimonialsSection from '@/components/TestimonialsSection';
import FAQSection from '@/components/FAQSection';
import PricingSection from '@/components/PricingSection';
import NewsletterSection from '@/components/NewsletterSection';

const HomePage = () => {
  return (
    <>
      <Helmet>
        <title>The Mindful Manifestation Digital Planner - Unlock Your Abundance</title>
        <meta name="description" content="Transform your life with The Mindful Manifestation Digital Planner. Design your dream life, master your energy, and achieve your goals faster with our elegant digital planning system." />
      </Helmet>
      <HeroSection />
      <BenefitsSection />
      <PreviewSection />
      <AuthorSection />
      <TestimonialsSection />
      <FAQSection />
      <PricingSection />
      <NewsletterSection />
    </>
  );
};

export default HomePage;
