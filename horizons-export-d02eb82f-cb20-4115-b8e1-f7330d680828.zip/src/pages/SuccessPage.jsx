import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { CheckCircle, ShoppingBag } from 'lucide-react';
import { Button } from '@/components/ui/button';

const SuccessPage = () => {
  return (
    <>
      <Helmet>
        <title>Payment Successful - Mindful Manifestation</title>
        <meta name="description" content="Your order has been successfully placed." />
      </Helmet>
      <div className="min-h-[calc(100vh-8rem)] flex items-center justify-center bg-gradient-to-br from-purple-50 via-white to-amber-50 p-4">
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5, type: 'spring' }}
          className="bg-white rounded-2xl shadow-luxury p-8 md:p-12 text-center max-w-2xl w-full"
        >
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2, duration: 0.5, type: 'spring', stiffness: 150 }}
            className="mx-auto w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mb-6"
          >
            <CheckCircle className="w-16 h-16 text-green-500" />
          </motion.div>
          <h1 className="font-display text-3xl md:text-4xl font-bold gradient-text mb-4">
            Thank You for Your Order!
          </h1>
          <p className="text-lg text-text-light mb-8">
            Your payment was successful and your order is being processed. You will receive a confirmation email shortly with your order details and download links.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/store">
              <Button className="btn-primary w-full sm:w-auto text-white px-8 py-3 rounded-full font-semibold text-base">
                <ShoppingBag className="mr-2 h-5 w-5" />
                Continue Shopping
              </Button>
            </Link>
            <Link to="/">
              <Button variant="outline" className="w-full sm:w-auto px-8 py-3 rounded-full font-semibold text-base border-primary-gold text-primary-gold hover:bg-amber-50 hover:text-primary-gold">
                Back to Home
              </Button>
            </Link>
          </div>
        </motion.div>
      </div>
    </>
  );
};

export default SuccessPage;