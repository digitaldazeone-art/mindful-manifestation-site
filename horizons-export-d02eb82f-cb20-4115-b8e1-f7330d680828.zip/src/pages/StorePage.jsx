import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import ProductsList from '@/components/ProductsList';

const StorePage = () => {
  return (
    <>
      <Helmet>
        <title>Our Store - Mindful Manifestation</title>
        <meta name="description" content="Explore our collection of digital products designed to help you manifest your dream life with intention and elegance." />
      </Helmet>
      <div className="bg-gradient-to-b from-purple-50 via-white to-amber-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12 md:py-20">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="text-center mb-12"
          >
            <h1 className="font-display text-4xl md:text-6xl font-bold gradient-text mb-4">
              Mindful Manifestation Store
            </h1>
            <p className="text-lg md:text-xl text-text-light max-w-3xl mx-auto">
              Discover tools and resources crafted with love to support your journey of conscious creation and personal growth.
            </p>
          </motion.div>
          <ProductsList />
        </div>
      </div>
    </>
  );
};

export default StorePage;