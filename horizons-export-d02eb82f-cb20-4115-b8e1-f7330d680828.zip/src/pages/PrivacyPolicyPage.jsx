import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';

const LegalPageLayout = ({ title, children }) => (
  <div className="bg-gradient-to-b from-purple-50 via-white to-amber-50 py-12 md:py-20">
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.7 }}
      >
        <div className="mb-8">
          <Link to="/" className="inline-flex items-center gap-2 text-text-dark hover:text-primary-gold transition-colors">
            <ArrowLeft size={16} />
            Back to Home
          </Link>
        </div>
        <div className="bg-white p-8 md:p-12 rounded-2xl shadow-luxury">
          <h1 className="font-display text-3xl md:text-5xl font-bold gradient-text mb-8 text-center">
            {title}
          </h1>
          <div className="prose prose-lg max-w-none text-text-light">
            {children}
          </div>
        </div>
      </motion.div>
    </div>
  </div>
);

const PrivacyPolicyPage = () => {
  return (
    <>
      <Helmet>
        <title>Privacy Policy - Mindful Manifestation</title>
        <meta name="description" content="Privacy Policy for the Mindful Manifestation Digital Planner website and products." />
      </Helmet>
      <LegalPageLayout title="Privacy Policy">
        <p>Last updated: {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</p>
        <p>Your privacy is important to us. It is Mindful Manifestation's policy to respect your privacy regarding any information we may collect from you across our website, and other sites we own and operate.</p>
        
        <h2>1. Information We Collect</h2>
        <p>We only ask for personal information when we truly need it to provide a service to you. We collect it by fair and lawful means, with your knowledge and consent. We also let you know why we’re collecting it and how it will be used.</p>
        <ul>
          <li><strong>Log data:</strong> When you visit our website, our servers may automatically log the standard data provided by your web browser.</li>
          <li><strong>Personal information:</strong> We may ask for personal information, such as your name, email, and payment information for purchases.</li>
        </ul>

        <h2>2. How We Use Your Information</h2>
        <p>We use the information we collect in various ways, including to:</p>
        <ul>
          <li>Provide, operate, and maintain our website</li>
          <li>Improve, personalize, and expand our website</li>
          <li>Understand and analyze how you use our website</li>
          <li>Process your transactions and send you related information, including purchase confirmations and invoices.</li>
          <li>Communicate with you, either directly or through one of our partners, including for customer service, to provide you with updates and other information relating to the website, and for marketing and promotional purposes.</li>
        </ul>

        <h2>3. Security of Your Personal Information</h2>
        <p>We value your trust in providing us your Personal Information, thus we are striving to use commercially acceptable means of protecting it. But remember that no method of transmission over the internet, or method of electronic storage is 100% secure and reliable, and we cannot guarantee its absolute security.</p>

        <h2>4. Cookies</h2>
        <p>We use "cookies" to collect information about you and your activity across our site. A cookie is a small piece of data that our website stores on your computer, and accesses each time you visit, so we can understand how you use our site.</p>

        <h2>5. Changes to This Privacy Policy</h2>
        <p>We may update our Privacy Policy from time to time. We will notify you of any changes by posting the new Privacy Policy on this page. You are advised to review this Privacy Policy periodically for any changes.</p>

        <h2>6. Contact Us</h2>
        <p>If you have any questions about this Privacy Policy, please contact us by email: support@mindfulmanifestation.com</p>
      </LegalPageLayout>
    </>
  );
};

export default PrivacyPolicyPage;