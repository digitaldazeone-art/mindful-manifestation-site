import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { LifeBuoy, Mail, MessageSquare } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';

const SupportPage = () => {
  const { toast } = useToast();

  const handleSubmit = (e) => {
    e.preventDefault();
    toast({
      title: "🚧 Feature In Progress",
      description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
    });
  };

  return (
    <>
      <Helmet>
        <title>Support - Mindful Manifestation</title>
        <meta name="description" content="Get help and support for the Mindful Manifestation digital planner. Contact us with your questions." />
      </Helmet>
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.5 }}
        className="bg-gradient-to-br from-purple-50 via-white to-amber-50"
      >
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 md:py-24">
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-center"
          >
            <div className="inline-block bg-gradient-to-r from-purple-500 to-yellow-500 p-4 rounded-full mb-6">
              <LifeBuoy className="w-12 h-12 text-white" />
            </div>
            <h1 className="font-display text-4xl md:text-5xl font-bold gradient-text mb-4">
              How can we help you?
            </h1>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              We're here to support you on your manifestation journey. Find answers to common questions or get in touch with our team.
            </p>
          </motion.div>

          <div className="mt-16 grid md:grid-cols-2 gap-8">
            <motion.div
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.4 }}
              className="bg-white p-8 rounded-2xl shadow-lg"
            >
              <h2 className="font-display text-2xl font-bold text-gray-800 mb-4">Contact Us Directly</h2>
              <p className="text-gray-600 mb-6">
                Have a specific question? Send us a message and we'll get back to you as soon as possible.
              </p>
              <form onSubmit={handleSubmit} className="space-y-4">
                <Input type="text" placeholder="Your Name" required />
                <Input type="email" placeholder="Your Email" required />
                <textarea
                  className="flex min-h-[120px] w-full rounded-md border border-input bg-transparent px-3 py-2 text-sm shadow-sm placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50"
                  placeholder="Your Message"
                  required
                ></textarea>
                <Button type="submit" className="btn-primary w-full text-white font-semibold">
                  Send Message
                </Button>
              </form>
            </motion.div>

            <motion.div
              initial={{ x: 20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.6 }}
              className="space-y-6"
            >
              <div className="bg-white p-6 rounded-2xl shadow-lg flex items-start space-x-4">
                <div className="flex-shrink-0 w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                  <Mail className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-800 text-lg">Email Support</h3>
                  <p className="text-gray-600">For general inquiries and support.</p>
                  <a href="mailto:support@mindfulmanifestation.com" className="text-purple-600 font-medium hover:underline">
                    support@mindfulmanifestation.com
                  </a>
                </div>
              </div>
              <div className="bg-white p-6 rounded-2xl shadow-lg flex items-start space-x-4">
                <div className="flex-shrink-0 w-12 h-12 bg-amber-100 rounded-xl flex items-center justify-center">
                  <MessageSquare className="w-6 h-6 text-amber-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-gray-800 text-lg">Community Forum</h3>
                  <p className="text-gray-600">Connect with other manifestors.</p>
                  <span className="text-gray-400 font-medium">Coming Soon!</span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </motion.div>
    </>
  );
};

export default SupportPage;