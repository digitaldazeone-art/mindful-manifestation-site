import { Resend } from 'resend';

const resend = new Resend(process.env.RESEND_API_KEY);

export async function handler(event) {
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'POST, OPTIONS',
      },
      body: '',
    };
  }

  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      body: 'Method Not Allowed',
      headers: { 'Access-Control-Allow-Origin': '*' },
    };
  }

  try {
    const { email } = JSON.parse(event.body);

    if (!email) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: 'Email is required' }),
        headers: { 'Access-Control-Allow-Origin': '*' },
      };
    }

    const emailHtml = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Your Free Mindful Manifestation Ebook is Here!</title>
      </head>
      <body>
        <h1>Thank you for subscribing!</h1>
        <p>Here is your free Mindful Manifestation Ebook. We're so excited to have you on this journey with us.</p>
        <p><a href="https://mindfulmanifestation.life/ebook.pdf" target="_blank" rel="noopener noreferrer">Click here to download your ebook</a></p>
        <p>With gratitude,</p>
        <p>The Mindful Manifestation Team</p>
      </body>
      </html>
    `;

    await resend.emails.send({
      from: 'Mindful Manifestation <onboarding@resend.dev>',
      to: email,
      subject: 'Your Free Mindful Manifestation Ebook is Here!',
      html: emailHtml,
    });

    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Success! Your ebook has been sent.' }),
      headers: { 'Access-Control-Allow-Origin': '*' },
    };

  } catch (error) {
    console.error('Function Error:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message || 'An unexpected error occurred.' }),
      headers: { 'Access-Control-Allow-Origin': '*' },
    };
  }
}